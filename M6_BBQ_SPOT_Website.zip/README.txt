M6 BBQ SPOT WEBSITE

Files:
- index.html
- assets/m6-bbq-logo.png

To preview:
Open index.html in any web browser.

Website details used:
Phone: 8616588
Location: Longolongo, facing the Police Station main gate
Hours: Monday-Saturday, 12:00 PM-12:00 AM
Menu:
- BBQ Mix T$15
- BBQ Chicken T$10
- BBQ Lamb Only T$18

Note:
The hours were entered as 12:00 PM to 12:00 AM, assuming the second "12:00 PM" supplied was meant to be midnight.
